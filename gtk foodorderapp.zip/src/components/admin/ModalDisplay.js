import * as React from "react";
import Box from "@mui/material/Box";
import Button from "@mui/material/Button";
import Typography from "@mui/material/Typography";
import Modal from "@mui/material/Modal";
import { ItemUseContext } from "../../content/item-contex";
const style = {
  position: "absolute",
  top: "50%",
  left: "50%",
  transform: "translate(-50%, -50%)",
  width: "80%",
  maxHeight: "90%",
  bgcolor: "background.paper",
  border: "2px solid #000",
  boxShadow: 24,
  p: 4,
};

export default function DisplayModal({ data, open, setModal }) {
  const { handleClose, modal } = ItemUseContext();
  const { sku, display, name, price, description, url } = data;

  let content;
  function add() {
    content = "additem";
  }
  function edit() {
    content = `${sku}+${price}`;
  }
  function erase() {
    content = "deleteitem";
  }

  switch (modal) {
    case 0:
      add();
      break;
    case 1:
      edit();
      break;
    case 2:
      erase();
      break;
    default:
      content = "nothing";
  }
  return (
    <div>
      <Modal
        open={open}
        onClose={handleClose}
        aria-labelledby="modal-modal-title"
        aria-describedby="modal-modal-description"
      >
        <Box sx={style}>
          <Typography id="modal-modal-title" variant="h6" component="h2">
            {content}
          </Typography>
        </Box>
      </Modal>
    </div>
  );
}
